package com.index.demoindexmettingroomreminderapp.data

enum class Emirate(val displayName: String) {
    ABU_DHABI("Abu Dhabi"),
    DUBAI("Dubai"),
    SHARJAH("Sharjah"),
    UMM_AL_QUWAIN("Umm Al Quwain"),
    RAS_AL_KHAIMAH("Ras Al Khaimah"),
    DESIGN("Design"),
    AGEC1("AGEC1"),
    AGEC2("AGEC2"),
    AGEC3("AGEC3"),
    AGEC4("AGEC4");
    // Optional: To easily get an Emirate from its display name
    companion object {
        fun fromDisplayName(name: String): Emirate? {
            return entries.find { it.displayName == name }
        }
    }
}