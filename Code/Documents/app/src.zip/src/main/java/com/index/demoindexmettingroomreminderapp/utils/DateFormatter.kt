package com.index.demoindexmettingroomreminderapp.utils

import java.text.SimpleDateFormat

import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Parses an ISO 8601 UTC date-time string into a user-friendly "hh:mm a" format.
 * This version is compatible with all Android API levels.
 */
fun formatToAmPmCompatible(dateTimeString: String): String {
    return try {
        val inputFormatWithZ = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSX", Locale.ENGLISH)
        inputFormatWithZ.timeZone = TimeZone.getTimeZone("UTC")

        val inputFormatWithoutZ = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS", Locale.ENGLISH)
        inputFormatWithoutZ.timeZone = TimeZone.getTimeZone("UTC")

        val outputFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH)

        val date = try {
            inputFormatWithZ.parse(dateTimeString)
        } catch (e: java.text.ParseException) {
            inputFormatWithoutZ.parse(dateTimeString)
        }
        outputFormat.format(date!!)
    } catch (e: Exception) {
        e.printStackTrace()
        "Invalid Time"
    }
}

/**
 * Parses a UTC date-time string from the API into a Date object for comparisons.
 * This is compatible with all Android API levels.
 */
fun parseUtcDateTime(dateTimeString: String): Date? {
    val inputFormatWithZ = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSSX", Locale.ENGLISH)
    inputFormatWithZ.timeZone = TimeZone.getTimeZone("UTC")

    val inputFormatWithoutZ = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS", Locale.ENGLISH)
    inputFormatWithoutZ.timeZone = TimeZone.getTimeZone("UTC")

    return try {
        try {
            inputFormatWithZ.parse(dateTimeString)
        } catch (e: java.text.ParseException) {
            inputFormatWithoutZ.parse(dateTimeString)
        }
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
