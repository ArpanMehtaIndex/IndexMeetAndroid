package com.index.demoindexmettingroomreminderapp.worker.countdown

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.index.demoindexmettingroomreminderapp.R
import com.index.demoindexmettingroomreminderapp.data.Constants
import com.index.demoindexmettingroomreminderapp.utils.AppLog
import kotlinx.coroutines.delay
import java.util.Locale
import java.util.concurrent.TimeUnit

class CountdownWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var isTtsInitialized = false

    companion object {
        const val NOTIFICATION_CHANNEL_ID = "MEETING_COUNTDOWN_CHANNEL"
        const val NOTIFICATION_ID = 12345
        const val KEY_MEETING_SUBJECT = "KEY_MEETING_SUBJECT"
        const val KEY_MEETING_START_TIME = "KEY_MEETING_START_TIME"
        const val KEY_MEETING_END_TIME = "KEY_MEETING_END_TIME"
    }

    override suspend fun doWork(): Result {
        val meetingSubject = inputData.getString(KEY_MEETING_SUBJECT) ?: "Current Meeting"
        val startTimeMillis = inputData.getLong(KEY_MEETING_START_TIME, 0L)
        val endTimeMillis = inputData.getLong(KEY_MEETING_END_TIME, 0L)

        if (endTimeMillis == 0L || System.currentTimeMillis() >= endTimeMillis) {
            return Result.success() // Meeting is already over, do nothing.
        }

        AppLog.d("CountdownWorker:", " Starting for '$meetingSubject'")

        // Initialize TTS
        tts = TextToSpeech(context, this)
        delay(500) // Give TTS a moment to initialize

        try {
            val foregroundInfo = createForegroundInfo("Preparing meeting status...")
            setForeground(foregroundInfo)

            // Loop until the meeting is over
                while (System.currentTimeMillis() < endTimeMillis) {
                    val currentLoopTime = System.currentTimeMillis()
                    val countdownStartTime = endTimeMillis - Constants.TEN_MINUTES_IN_MILLIS

                    val notificationText = when {
                        // State 1: Countdown is active (within the last 10 minutes)
                        currentLoopTime >= countdownStartTime -> {
                            val remainingSeconds = (endTimeMillis - currentLoopTime) / 1000
                            val minutes = remainingSeconds / 60
                            val seconds = remainingSeconds % 60
                            String.format(
                                Locale.getDefault(),
                                "Ends in: %02d:%02d",
                                minutes,
                                seconds
                            )
                        }
                        // State 2: Meeting has started but not in countdown window yet
                        currentLoopTime >= startTimeMillis -> {
                            Constants.ONGOING_MEETING
                        }
                        // State 3: Waiting for the meeting to start
                        else -> {
                            Constants.MEETING_NOT_STARTED_YET
                        }
                    }
                    // This prevents your notification tray from being spammed.
                    if (notificationText == Constants.MEETING_NOT_STARTED_YET) {
                        // Option 1: Don't show a notification at all yet.
                        // We can just delay until the meeting starts.
                        val delayDuration = startTimeMillis - currentLoopTime
                        if (delayDuration > 0) {
                            delay(delayDuration)
                        }
                        continue
                    }
                    updateNotification("$meetingSubject: $notificationText")
                    delay(1000)

                }

            // --- At this point, the meeting has finished ---
            updateNotification("$meetingSubject: ${Constants.MEETING_ENDED}")
            val messageToSpeak = "$meetingSubject ${Constants.MEETING_FINISHED_MESSAGE}"
            speakMessage(messageToSpeak)
            delay(5000) // Wait for TTS
        } catch (e: Exception) {
            AppLog.e("CountdownWorker: Error during countdown", e.toString())
            return Result.failure()
        } finally {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(NOTIFICATION_ID)
        }

        return Result.success()
    }

    private fun createForegroundInfo(contentText: String): ForegroundInfo {
        val notification = createNotification(contentText)

        // For Android 14+ we must specify the service type
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ForegroundInfo(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    // --- Helper Functions for Notification and TTS ---
    private fun createNotification(contentText: String): Notification {
        createNotificationChannel()
        return NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
            .setContentTitle(Constants.MEETING_STATUS)
            .setContentText(contentText)
            .setSmallIcon(R.drawable.ic_room)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(contentText: String) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = createNotification(contentText)
        notificationManager.notify(NOTIFICATION_ID, notification)
    }

    // ... (createNotificationChannel, onInit, speakMessage are the same)
    private fun createNotificationChannel() {
        if (
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Meeting Countdown Channel"
            val descriptionText = "Notifications for meeting end times"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance).apply {
                description = descriptionText
                setShowBadge(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val notificationManager =
                context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                AppLog.e("TTS:", " Language not supported!")
            } else {
                isTtsInitialized = true
            }
        } else {
            AppLog.e("TTS: ", "Initialization Failed!")
        }
    }

    private fun speakMessage(message: String) {
        if (isTtsInitialized) {
            tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, null)
        }
    }
}
