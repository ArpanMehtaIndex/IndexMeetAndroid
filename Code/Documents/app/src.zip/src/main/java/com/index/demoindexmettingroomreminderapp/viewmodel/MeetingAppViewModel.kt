package com.index.demoindexmettingroomreminderapp.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.index.demoindexmettingroomreminderapp.data.Constants
import com.index.demoindexmettingroomreminderapp.data.Emirate
import com.index.demoindexmettingroomreminderapp.data.PreferenceHelper
import com.index.demoindexmettingroomreminderapp.utils.parseUtcDateTime
import com.index.demoindexmettingroomreminderapp.web.UiState
import com.index.demoindexmettingroomreminderapp.web.model.response.CalendarViewResponse
import com.index.demoindexmettingroomreminderapp.web.model.response.TokenResponse
import com.index.demoindexmettingroomreminderapp.web.repository.MeetingAppRepo
import com.index.demoindexmettingroomreminderapp.worker.countdown.manager.CountdownInfo
import com.index.demoindexmettingroomreminderapp.worker.countdown.manager.CountdownManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

class MeetingAppViewModel(application: Application) : AndroidViewModel(application) {
    private val meetingAppRepo = MeetingAppRepo(application.applicationContext)

    // ... (tokenUiState remains the same)
    private val _tokenUiState = MutableStateFlow<UiState<TokenResponse>>(UiState.Idle)
    val tokenUiState: StateFlow<UiState<TokenResponse>> = _tokenUiState.asStateFlow()

    private val _activeCountdownMeetingId = MutableStateFlow<String?>(null)
    val activeCountdownMeetingId: StateFlow<String?> = _activeCountdownMeetingId.asStateFlow()

    private val _countdownSeconds = MutableStateFlow(0)
    val countdownSeconds: StateFlow<Int> = _countdownSeconds.asStateFlow()

    private var countdownJob: Job? = null


    private val _calendarUiState = MutableStateFlow<UiState<CalendarViewResponse>>(UiState.Idle)
    val calendarUiState: StateFlow<UiState<CalendarViewResponse>> = _calendarUiState.asStateFlow()

    init {
        // Listen for triggers from the worker
        viewModelScope.launch {
            CountdownManager.startCountdownForMeeting.collect { countdownInfo ->
                startOrUpdateCountdown(countdownInfo.endTimeMillis, countdownInfo.meetingId)
            }
        }
    }

    fun checkAndStartCountdownIfNeeded() {
        val calendarState = _calendarUiState.value
        if (calendarState is UiState.Success) {
            val meetings = calendarState.data.value
            val now = System.currentTimeMillis()

            val meetingToTrack = meetings.find { 
                val endTime = parseUtcDateTime(it.end.dateTime)?.time ?: 0L
                val tenMinutesBeforeEnd = endTime - Constants.TEN_MINUTES_IN_MILLIS
                // Check if we are inside the 10-minute window
                now in tenMinutesBeforeEnd until endTime
            }

            if (meetingToTrack != null) {
                val endTime = parseUtcDateTime(meetingToTrack.end.dateTime)?.time ?: 0L
                startOrUpdateCountdown(endTime, meetingToTrack.id)
            }
        }
    }

    private fun startOrUpdateCountdown(endTimeMillis: Long, meetingId: String) {
        countdownJob?.cancel() // Cancel any existing countdown
        _activeCountdownMeetingId.value = meetingId

        countdownJob = viewModelScope.launch {
            var remainingMillis = endTimeMillis - System.currentTimeMillis()

            while (remainingMillis > 0) {
                _countdownSeconds.value = (remainingMillis / 1000).toInt()
                delay(1000)
                remainingMillis = endTimeMillis - System.currentTimeMillis()
            }

            // Countdown finished
            _countdownSeconds.value = 0
            _activeCountdownMeetingId.value = null
        }
    }

    private fun startCountdown(info: CountdownInfo) {
        countdownJob?.cancel() // Cancel any existing countdown
        _activeCountdownMeetingId.value = info.meetingId

        countdownJob = viewModelScope.launch {
            val endTime = info.endTimeMillis
            var remainingMillis = endTime - System.currentTimeMillis()

            while (remainingMillis > 0) {
                _countdownSeconds.value = (remainingMillis / 1000).toInt()
                delay(1000)
                remainingMillis = endTime - System.currentTimeMillis()
            }

            // Countdown finished
            _countdownSeconds.value = 0
            _activeCountdownMeetingId.value = null
            // The TTS logic will now be handled in the UI based on this state change
        }
    }

    /**
     * Class: MeetingAppViewModel.KT
     * Method: fetchAccessToken()
     * Created By: Arpan Mehta
     * Created On: 22/12/2025
     * Modified On: 22/12/2025
     * Description: This method is use to fetch token from from api.
     **/
    fun fetchAccessToken() {
        _tokenUiState.value = UiState.Loading

        viewModelScope.launch {
            meetingAppRepo.getAccessToken()
                .catch { exception ->
                    _tokenUiState.value = UiState.Error(exception.message ?: "An unknown error occurred")
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { tokenResponse ->
                            _tokenUiState.value = UiState.Success(tokenResponse)
                        },
                        onFailure = { exception ->
                            _tokenUiState.value = UiState.Error(exception.message ?: "Failed to fetch token")
                        }
                    )
                }
        }
    }

/**
 * Class: MeetingAppViewModel.KT
 * Method: fetchCalendarEvents()
 * Created By: Arpan Mehta
 * Created On: 22/12/2025
 * Modified On: 22/12/2025
 * Description: This method is use to fetch calender events(meeting list) from api.
 **/
    fun fetchCalendarEvents(loadFromLocalData: Boolean = false) {
        _calendarUiState.value = UiState.Loading
        viewModelScope.launch {
            if (loadFromLocalData) {
                try {
                    val inputStream = getApplication<Application>().assets.open("MeetingRoomSampleJson.json")
                    val reader = InputStreamReader(inputStream)
                    val response = Gson().fromJson(reader, CalendarViewResponse::class.java)
                    _calendarUiState.value = UiState.Success(response)
                } catch (e: Exception) {
                    _calendarUiState.value = UiState.Error("Failed to load local data: ${e.message}")
                }
            } else {
                val selectedEmirate = PreferenceHelper.getSelectedEmirate(getApplication())
                val userEmail = when (selectedEmirate) {
                    Emirate.ABU_DHABI -> "auh@index.ae"
                    Emirate.DUBAI -> "dubai@index.ae"
                    Emirate.SHARJAH -> "sharjah@index.ae"
                    Emirate.RAS_AL_KHAIMAH -> "rak@index.ae"
                    Emirate.DESIGN -> "design.meeting@index.ae"
                    Emirate.AGEC1 -> "agec1@index.ae"
                    Emirate.AGEC2 -> "agec2@index.ae"
                    Emirate.AGEC3 -> "agec3@index.ae"
                    Emirate.AGEC4 -> "agec4@index.ae"
                    else -> {
                        // Fallback or error case if no emirate is selected
                        _calendarUiState.value = UiState.Error("No meeting room selected.")
                        return@launch
                    }
                }

                val calendar = Calendar.getInstance()
                val utcTimeZone = TimeZone.getTimeZone("UTC")
                val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                    timeZone = utcTimeZone
                }

                calendar.set(Calendar.HOUR_OF_DAY, 7)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                val startDateTime = isoFormat.format(calendar.time)

                // Set to end of the day (e.g., 10:00 PM UTC)
                calendar.set(Calendar.HOUR_OF_DAY, 22)
                calendar.set(Calendar.MINUTE, 0)
                calendar.set(Calendar.SECOND, 0)
                val endDateTime = isoFormat.format(calendar.time)

                meetingAppRepo.getCalendarEvents(userEmail, startDateTime, endDateTime)
                    .catch { e ->
                        _calendarUiState.value = UiState.Error(e.message ?: "An unknown error occurred")
                    }
                    .collect { result ->
                        result.fold(
                            onSuccess = { response ->
                                _calendarUiState.value = UiState.Success(response)
                            },
                            onFailure = { e ->
                                _calendarUiState.value = UiState.Error(e.message ?: "Failed to fetch calendar events")
                            }
                        )
                    }
            }
        }
    }
}
