package com.index.demoindexmettingroomreminderapp.data

import androidx.compose.ui.graphics.Color

object Constants {
    const val REFRESH_TOKEN_WORKER_NAME="tokenRefreshWork"
    const val COUNTDOWN_TOKEN_WORKER_NAME="meeting_end_"
    const val SPLASH_WELCOME_MESSAGE="Welcome to"
    const val APP_NAME="Index Meet"
    const val ONGOING_MEETING="On going meeting"
    const val MEETING_DIALOG_TITLE="Meeting Concluded"
    const val MEETING_DETAILS="Meeting DETAILS"
    const val MEETING_STATUS="Meeting Status"
    const val NO_MEETING_IN_PROGRESS="No meeting is currently in progress."

    const val ERROR_IN_FETCHING_MEETING="No meeting is currently in progress."
    const val PLEASE_WAIT_MEETING_SCHEDULE="Please wait, loading schedule..."

    const val STARTS_LABEL = "Starts: "
    const val ENDS_LABEL = "Ends: "
    const val ORGANIZER_LABEL = "Organizer: "
    const val SUBJECT_LABEL = "Subject: "
    const val FETCHING_MEETING="Fetching meetings..."

    const val MEETING_ENDED="Meeting has ended."
    const val MEETING_ROOM="Meeting Room."

    const val MEETING_GOING_TO_END_IN="Meeting is going to end in "
    const val MEETING_NOT_STARTED_YET="Meeting has not started yet"

    const val MINUTES="Minutes "
    const val MEETING_CHANNEL="Meeting Countdown Channel"
    const val MEETING_NOTIFICATION_DESCRIPTION="Notifications for meeting details and timings"

    const val OK="OK"
    const val SPLASH_ANIMATION="ic_splash_animation.json"
    const val MEETING_FINISHED_MESSAGE="meeting time has been concluded. Please vacate the room for the upcoming meeting. Thank you."
    val THEME_COLOR = Color(0xFF1B68A5)
    val MEETING_HIGH_LIGHT_COLOR = Color(0xFFC8E6C9)
    const val TEN_MINUTES_IN_MILLIS = 10 * 60 * 1000L // 10 minutes in milliseconds
    const val MIN_TIMER_MINUTE=10
}